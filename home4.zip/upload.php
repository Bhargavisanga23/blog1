<?php
$servername = "localhost";
$dbname = "blog";
$username = "root";
$password = "";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$title = $_POST['title'] ?? '';
$content = $_POST['content'] ?? '';
$place = $_POST['place'] ?? '';
$date = $_POST['date'] ?? '';

// Prepare the SQL query
$stmt = $conn->prepare("INSERT INTO upload (title, content, place, date) VALUES (?, ?, ?, ?)");

if ($stmt === false) {
    die("Error: " . $conn->error); // Add error handling for statement preparation
}

$stmt->bind_param("ssss", $title, $content, $place, $date);

if ($stmt->execute()) {
    echo "Upload successful!";
} else {
    echo "Upload failed. Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>